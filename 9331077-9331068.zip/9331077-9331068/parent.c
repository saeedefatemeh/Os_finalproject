#include "types.h"
#include "stat.h"
#include "user.h"

void myPrint(int pid){
	int j;
	for(j = 0 ; j < 10 ; j++ ){
		printf(2, "child id is %d\n", pid);
	}
	exit();
}

int main(){

	int cid[30], wTime[30], rTime[30];
	int i = 0;
	for( i = 0 ; i < 30 ; i++ ){
		cid[i] = fork();
		 if( cid[i] == 0 ){
			if( i % 3 == 0 ){
				nice();
			}
			else if( i % 3 == 1 ){ 
				nice();
				nice();
			}
			int j;
		for(j = 0 ; j < 10 ; j++ ){
		printf(2, "child id is %d\n", i);
			}
		exit();	
		}

	}

	for( i = 0 ; i < 30 ; i++ ){
		wait2( &wTime[i], &rTime[i] );
	}
	int wTimetotal = 0 , wTimeavrage = 0;
	int rTimetotal = 0 , rTimeavrage = 0;
	int counter1 = 0 , counter2 = 0 , counter3 = 0;
	int wTimetotal1 = 0 , wTimeavrage1 = 0 , rTimetotal1 = 0 , rTimeavrage1 = 0 ;
	int wTimetotal2 = 0 , wTimeavrage2 = 0 , rTimetotal2 = 0 , rTimeavrage2 = 0 ;
	int wTimetotal3 = 0 , wTimeavrage3 = 0 , rTimetotal3 = 0 , rTimeavrage3 = 0 ;
	for(int k = 0; k <30 ; k++)
		{
			wTimetotal = wTimetotal+ wTime[k];
			rTimetotal = rTimetotal+ rTime[k];
			if(k%3 == 0)
			{
			wTimetotal1 = wTimetotal1+ wTime[k];
			rTimetotal1 = rTimetotal1+ rTime[k];
			counter1 ++;
			}
			if(k%3 == 1)
			{
			wTimetotal2 = wTimetotal2+ wTime[k];
			rTimetotal2 = rTimetotal2+ rTime[k];
			counter2 ++;
			}
			if(k%3 == 2)
			{
			wTimetotal3 = wTimetotal3 + wTime[k];
			rTimetotal3 = rTimetotal3 + rTime[k];
			counter3 ++;
			}
		}
	wTimeavrage = wTimetotal / 30;
	rTimeavrage = rTimetotal / 30;
	wTimeavrage1 = wTimetotal1 / counter1;
	rTimeavrage1 = rTimetotal1 / counter1;
	wTimeavrage2 = wTimetotal2 / counter2;
	rTimeavrage2 = rTimetotal2 / counter2;
	wTimeavrage3 = wTimetotal3 / counter3;
	rTimeavrage3 = rTimetotal3 / counter3;
	printf(1, " wTimeavrage  : %d , TurnaroundTimetotal : %d \n", wTimeavrage, wTimeavrage+rTimeavrage);
	printf(1, " wTimeavrage1  : %d , TurnaroundTimetotal1 : %d \n", wTimeavrage1, wTimeavrage1+rTimeavrage1);
	printf(1, " wTimeavrage2  : %d , TurnaroundTimetotal2 : %d \n", wTimeavrage2, wTimeavrage2+rTimeavrage2);
	printf(1, " wTimeavrage3  : %d , TurnaroundTimetotal3 : %d \n", wTimeavrage3, wTimeavrage3+rTimeavrage3);
	for(int t = 0; t <30 ; t++)
		{
			printf(1, "cid : %d wTime  : %d , TurnaroundTime : %d  \n" ,t, wTime[t] , wTime[t]+rTime[t]);
		}

	return 0;
}
